

package com.mycompany.runapplication2;

import java.util.Scanner;

public class RunApplication2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter console device type (PS5 / XBOX / SWITCH): ");
        String type = input.nextLine();

        System.out.print("Enter store name: ");
        String store = input.nextLine();

        System.out.print("Enter total amount of sales: ");
        int sales = input.nextInt();

        // Instantiate ConsoleSales class
        ConsoleSales sale = new ConsoleSales(type, store, sales);

        // Print report
        sale.printReport();

        input.close();
    }
}
    

