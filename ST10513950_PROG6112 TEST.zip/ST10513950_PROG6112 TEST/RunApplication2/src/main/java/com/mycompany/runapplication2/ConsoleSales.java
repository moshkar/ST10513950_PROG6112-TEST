
package com.mycompany.runapplication2;


public class ConsoleSales extends console {
    
    
}
