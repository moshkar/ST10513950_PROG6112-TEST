
package com.mycompany.runapplication2;


public abstract class Console implements IConsole {
    
    public abstract class Consoles implements IConsoles {
    // variables
    String consoleType;
    String storeName;
    int totalSales;

    // constructor
    public Consoles(String consoleType, String storeName, int totalSales) {
        this.consoleType = consoleType;
        this.storeName = storeName;
        this.totalSales = totalSales;
    }

    // get methods - required by interface
    @Override
    public String getConsoleType() {
        return consoleType;
    }

    @Override
    public String getStore() {
        return storeName;
    }

    @Override
    public int getTotalSales() {
        return totalSales;
    }
}
    
}
