package com.mycompany.numberofelectronics;


public class NumberOfElectronics {

    
    public static void main(String[] args) {

        // Single dimensional array for cities
        String[] cities = {"CAPE TOWN", "PORT ELIZABETH", "PRETORIA"};

        // Single dimensional array for console types
        String[] consoles = {"PS5", "XBOX", "SWITCH"};

        // Two dimensional array for sales data
        
        int[][] sales = {
            {1000, 2000, 3000}, // Cape Town
            {2000, 3000, 4000}, // Port Elizabeth
            {1500, 1100, 1200} // Pretoria
        };

        // Variables for total and city with most sales
        int[] totalSales = new int[3];
        int maxSales = 0;
        String cityWithMostSales = "";

        // Calculate total sales for each city
        for (int i = 0; i < 3; i++) {
            totalSales[i] = sales[i][0] + sales[i][1] + sales[i][2];

            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                cityWithMostSales = cities[i];
            }
        }

        // Display the report
        System.out.println("----------------------------------------------------------");
        System.out.println("GAMING CONSOLE REPORT");
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-20s %-10s %-10s %-10s\n", "", consoles[0], consoles[1], consoles[2]);
        System.out.println();

        for (int i = 0; i < 3; i++) {
            System.out.printf("%-20s %-10d %-10d %-10d\n", cities[i], sales[i][0], sales[i][1], sales[i][2]);
        }

        System.out.println();
        System.out.println("----------------------------------------------------------");
        System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");
        System.out.println("----------------------------------------------------------");

        for (int i = 0; i < 3; i++) {
            System.out.println(cities[i] + "\t" + totalSales[i]);
        }

        System.out.println();
        System.out.println("CITY WITH THE MOST SALES: " + cityWithMostSales);
        System.out.println("----------------------------------------------------------");
    }
}
        
        
    

